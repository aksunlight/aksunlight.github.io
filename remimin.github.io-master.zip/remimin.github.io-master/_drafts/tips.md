hostname

`hostname -I` 查看本机所有ip
