RamDisk

# 什么是RamDisk

RamDisk顾名思义，其实就是以系统的Ram作为disk