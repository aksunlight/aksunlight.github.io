---
layout:     post
title:      "CPU拓扑"
subtitle:   ""
date:       2018-05-12
author:     "min"
header-img: "img/post-bg-2015.jpg"
tags:
    - CPU, virtualization
---
# CPU 拓扑

Linux下查看cpu拓扑可以通过/proc/cpuinfo