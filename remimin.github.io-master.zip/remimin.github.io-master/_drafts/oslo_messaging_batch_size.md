问题1： batch_size 较大，message很少
问题2： batch_size = 1
问题3: batch_timeout = None 
问题4：executor_thread_pool_size