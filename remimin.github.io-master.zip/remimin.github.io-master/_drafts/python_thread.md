---
layout:     post
title:      "从Openstack Bug学习python thread"
subtitle:   ""
date:       2018-05-12
author:     "min"
header-img: "img/post-bg-2015.jpg"
tags:
    - Openstack, Thread
---
